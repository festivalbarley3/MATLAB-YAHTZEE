Intructions on how to use monty carlo simulation of yahtzee
The objective of this code is to find out how many rolls it takes to get a yahtzee over many throws of the dice
To run the code 
Step 1 hit run
Step 2 enter an amount of times you want to do this simulation. The amount of dice thrown by default is 5 ***
Step 3 let it run and read the data
*** if you want to add onto the amount of dice thrown or change edit the monty carlo script by changing p to a different number***